export class GetSubspecialtiesQuery {}
