import { Injectable } from '@nestjs/common';

@Injectable()
export class PersonalDataService {
  constructor() { }
}
